# AWA T-shirt Shop

Ce projet est une boutique en ligne de T-shirts développée avec :
- HTML/CSS/JS pour le frontend
- Node.js + Express pour le backend
- Stripe pour les paiements
- MongoDB pour enregistrer les commandes

## Déploiement sur GitHub

### 1. Initialiser Git

```bash
git init
git add .
git commit -m "Initial commit"
```

### 2. Créer le dépôt sur GitHub

Créer un dépôt vide sur [https://github.com/stickgeko/awa-tshirt-shop](https://github.com/stickgeko/awa-tshirt-shop)

### 3. Lier le dépôt

```bash
git remote add origin https://github.com/stickgeko/awa-tshirt-shop.git
git branch -M main
git push -u origin main
```

## Lancement local

```bash
npm install
node server.js
```

## Sécurité

Ajoutez vos clés secrètes dans un fichier `.env` (voir plus bas) et ne les poussez jamais dans GitHub.

## Exemple de `.env`

```
STRIPE_SECRET_KEY=sk_test_XXXXXX
MONGO_URI=mongodb+srv://user:pass@cluster.mongodb.net/db
```

Ajoutez `.env` à `.gitignore`.
